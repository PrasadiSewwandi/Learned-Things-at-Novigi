import setuptools

setuptools.setup(
    name='poosa',
)